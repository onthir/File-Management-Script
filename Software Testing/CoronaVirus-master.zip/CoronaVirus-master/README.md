# CoronaVirus

Super simple android app that I created for myself to see the current stats of coronavirus
